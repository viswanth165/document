import os, signal
import sh

op = (sh.grep(sh.ps("ax"), 'start_api.py'))
res = op.split()[0]
# print(op)
# print(res)
# # os.kill(int(res), signal.SIGKILL)

try:
    os.kill(int(res), signal.SIGKILL)
    print("Process Successfully terminated")

except Exception:
    print("Error Encountered while running script")
