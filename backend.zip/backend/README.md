
# Chaos  Backend

This is the backend application for chaos. The application is written in Pyhon.

## Developer Environment Setup

```shell
https://github.com/chaos-backend/backend.git
cd backend
```

## Running the Application
This repo contains the backend part of chaos application.

## Install
### Install all packages in requirements file
In this file all packages are available just install these packages

### This package requires Python 3.6+

To be used from your experiment, this package must be installed in the Python environment where chaostoolkit already lives.

```shell
pip install -U chaostoolkit-aws
````
To run the  backend script execute the follow command.
```shell
 uvicorn src.main:app --reload
```


