import uvicorn
from multiprocessing import current_process


uvicorn.run("src.main:app", host="127.0.0.1", port=5000, log_level="info")
def start_api():
    process = current_process()
    pid = process.pid
    return pid