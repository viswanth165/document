from typing import Union, List, Dict, Any
from pydantic import BaseModel


class AWS(BaseModel):
    id: Union[str, None] = None
    ids: List[str] = None
    filters: List[Dict[str, Any]] = None
    clusterArns: List[str] = None
    serviceArns: List[str] = None
    taskArns: List[str] = None
