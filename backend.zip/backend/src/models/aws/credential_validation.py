from pydantic import BaseModel


class CredentialValidation(BaseModel):
    key_id: str
    secret: str
    region: str
