from fastapi import FastAPI

from src.controllers.base import *


def application(app):
    run(app)


app = FastAPI()
application(app)
