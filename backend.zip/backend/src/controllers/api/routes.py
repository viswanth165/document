from fastapi import APIRouter
from fastapi import Request, Response, status

import sys
import src.cloud.aws.ec2.base
import src.cloud.aws.ecs.base
import src.models.aws.base
import src.cloud.aws.list.base
import src.cloud.aws.rds.base
import src.cloud.aws.s3.base
import src.cloud.aws.eks.base
import src.cloud.aws.autoscaling.base
import src.cloud.aws.ddb.base

from src.controllers.iam.aws.validate import gate

router = APIRouter(prefix="/api")
v1 = APIRouter(prefix="/v1")
cloud = APIRouter(prefix="/cloud")
aws = APIRouter(prefix="/aws")
ec2 = APIRouter(prefix="/ec2")
ecs = APIRouter(prefix="/ecs")
rds = APIRouter(prefix="/rds")
s3 = APIRouter(prefix="/s3")
eks = APIRouter(prefix="/eks")
asg = APIRouter(prefix="/asg")
dynamoDB = APIRouter(prefix="/dynamoDB")


def organizerouter(app):
    aws.include_router(dynamoDB)
    aws.include_router(asg)
    aws.include_router(eks)
    aws.include_router(s3)
    aws.include_router(rds)
    aws.include_router(ecs)
    aws.include_router(ec2)
    cloud.include_router(aws)
    v1.include_router(cloud)
    router.include_router(v1)
    app.include_router(router)


def Initializeroutes(app):
    @aws.get("/")
    async def list_services():
        return src.cloud.aws.list.base.list_services()

    @aws.get("/resources")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.list.base.list_resources(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/ec2")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.ec2_resources(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.get("/describe_actions")
    async def describe_actions():
        return src.cloud.aws.ec2.base.describe_actions()

    @ec2.get("/describe_instance/{id}")
    async def describe_instances(id, request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.describe_instances(request, id, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.put("/terminate_instance/{id}")
    async def terminate_instance(id, request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.terminate_instance(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.put("/stop-instance/{id}")
    async def stop_instance(id, request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.stop_instance(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.put("/stop-instances/{id}")
    async def stop_instances(id, request, response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.stop_instances(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.put("/start-instances/{id}")
    async def start_instances(id, request, response):
        err = gate(request)
        try:
            print(id)
            return src.cloud.aws.ec2.base.start_instances(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.post("/restart-instances/{id}")
    async def restart_instances(id, request, response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.restart_instances(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ec2.post("/detach_random_volume/{id}")
    async def detach_random_volume(id, request, response):
        err = gate(request)
        try:
            return src.cloud.aws.ec2.base.detach_random_volume(id, request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/ecs")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.ecs_resources(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/describe_cluster/{cluster}")
    async def describe_cluster(cluster, request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.describe_cluster(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/list_services")
    async def list_services(cluster, request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.list_services(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/describe_service/{services}")
    async def describe_service(request: Request, response: Response, cluster, services):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.describe_service(request, response, cluster, services)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/list_tasks")
    async def list_cluster_tasks(request: Request, response: Response, cluster):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.list_cluster_tasks(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/list_tasks/{service}")
    async def list_service_tasks(request: Request, response: Response, cluster, service):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.list_service_tasks(request, response, cluster, service)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/describe_tasks/{task}")
    async def describe_tasks(request: Request, response: Response, cluster, task):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.describe_tasks(request, response, cluster, task)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/list_container_instances")
    async def list_container_instances(request: Request, response: Response, cluster):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.list_container_instances(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @ecs.get("/{cluster}/describe_container_instance/{containerInstance}")
    async def describe_container_instance(request: Request, response: Response, cluster, containerInstance):
        err = gate(request)
        try:
            return src.cloud.aws.ecs.base.describe_container_instances(request, response, cluster, containerInstance)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/eks")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.eks.base.eks_resources(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @eks.get("/{cluster}/describe_cluster")
    async def describe_cluster(request: Request, response: Response, cluster):
        err = gate(request)
        try:
            return src.cloud.aws.eks.base.describe_cluster(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @eks.get("/{cluster}/node_groups")
    async def list_nodegroups(request:Request, response: Response, cluster):
        err = gate(request)
        try:
            return src.cloud.aws.eks.base.list_nodegroups(request, response, cluster)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @eks.get("/{cluster}/describe_nodegroup/{nodegroup}")
    async def describe_nodegroup(request: Request, response: Response, cluster, nodegroup):
        err = gate(request)
        try:
            return src.cloud.aws.eks.base.describe_nodegroup(request, response, cluster, nodegroup)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/lambda")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.list.base.lambda_resources(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/lambda/{function}/describe_function")
    async def describe_function(request: Request, response: Response, function):
        err = gate(request)
        try:
            return src.cloud.aws.list.base.describe_function(request, response, function)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/s3")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.list.base.s3_resource(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @s3.get("/{bucket}/describe_bucket")
    async def describe_bucket(request: Request, response: Response, bucket):
        err = gate(request)
        try:
            return src.cloud.aws.s3.base.describe_bucket(request, response, bucket)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @s3.get("/{bucket}/list_bucket_versioning")
    async def list_bucket_versioning(request: Request, response: Response, bucket):
        err = gate(request)
        try:
            return src.cloud.aws.s3.base.list_bucket_versioning(request, response, bucket)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/rds")
    async def list_db_cluster(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.rds.base.list_db_cluster(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @rds.get("/{dbclusteridentifier}/describe_db_cluster")
    async def describe_db_cluster(request: Request, response: Response, dbclusteridentifier):
        err = gate(request)
        try:
            return src.cloud.aws.rds.base.describe_db_cluster(request, response, dbclusteridentifier)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @rds.get("/{dbclusteridentifier}/{dbinstanceidentifier}/describe_db_instance")
    async def describe_db_instances(request: Request, response: Response, dbinstanceidentifier):
        err = gate(request)
        try:
            return src.cloud.aws.rds.base.describe_db_instances(request, response, dbinstanceidentifier)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/asg")
    async def list_asg(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.autoscaling.base.list_asg(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @asg.get("/{asgname}/describe_asg")
    async def describe_auto_scaling_groups(request: Request, response: Response, asgname):
        err = gate(request)
        try:
            return src.cloud.aws.autoscaling.base.describe_auto_scaling_groups(request, response, asgname)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @aws.get("/dynamoDB")
    async def root(request: Request, response: Response):
        err = gate(request)
        try:
            return src.cloud.aws.ddb.base.list_table(request, response)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    @dynamoDB.get("/{table}/describe_table")
    async def describe_table(request: Request, response: Response, table):
        err = gate(request)
        try:
            return src.cloud.aws.ddb.base.describe_table(request, response, table)
        except Exception:
            if err is not None:
                response.status_code = status.HTTP_401_UNAUTHORIZED
                return err
            else:
                ex_type, ex_value, ex_traceback = sys.exc_info()
                print("Error:", ex_value)

    organizerouter(app)
