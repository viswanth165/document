import boto3


def gate(request):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    # region_name = request.headers.get("aws_region")
    # print("secret :", aws_access_key_id, aws_secret_access_key)
    if aws_access_key_id is None or aws_secret_access_key is None or region_name is None:
        print("Credentials Not set..")
        return "Credentials not set..."

    sts = boto3.client('sts', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=region_name)
    print(sts.get_caller_identity())

    return
