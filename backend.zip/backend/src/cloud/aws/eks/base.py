import boto3
from starlette import status


def eks_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    eks = boto3.client('eks', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = eks.list_clusters()
    result = {"RequestId": res["ResponseMetadata"]["RequestId"],
              "Clusters": res["clusters"]}
    response.status_code = status.HTTP_200_OK
    return result


def describe_cluster(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    eks = boto3.client('eks', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    # cluster = [name]
    res = eks.describe_cluster(name=cluster)
    ret = {key: res[key] for key in res if key == "cluster"}
    response.status_code = status.HTTP_200_OK
    return ret


def list_nodegroups(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    eks = boto3.client('eks', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = eks.list_nodegroups(clusterName=cluster)
    ret = {key: res[key] for key in res if key == "nodegroups"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_nodegroup(request, response, cluster, nodegroup):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    eks = boto3.client('eks', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = eks.describe_nodegroup(clusterName=cluster, nodegroupName=nodegroup)
    ret = {key: res[key] for key in res if key == "nodegroup"}
    response.status_code = status.HTTP_200_OK
    return ret
