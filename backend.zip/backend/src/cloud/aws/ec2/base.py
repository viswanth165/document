import boto3
import chaosaws.ec2.actions
import chaosaws.ec2.probes
from typing import List, Dict, Any

from starlette import status


def describe_actions():
    actions = ["Start Instance", "Stop Instance", "Terminate Instance"]
    return actions


def ec2_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ec2 = boto3.resource('ec2', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                         region_name=region_name)
    # datas = ec2.instances.all()
    datas = []
    for instance in ec2.instances.all():
        data = {
                "Id": instance.id,
                "Platform": instance.platform_details,
                "Type": instance.instance_type,
                "State": instance.state,
                "Public DNS Name": instance.public_dns_name,
                "Public IP": instance.public_ip_address,
                "Private DNS": instance.private_dns_name,
                "Private IP": instance.private_ip_address,
                "Tags": instance.tags
                }
        datas.append(data)
    response.status_code = status.HTTP_200_OK
    return datas


def describe_instances(request, id, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")

    client = boto3.client('ec2', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.describe_instances(InstanceIds=id.split(','))
    ret = {key:res[key] for key in res if key == "Reservations"}
    response.status_code = status.HTTP_200_OK
    return ret


def attach_volume(id, request, response):
    configuration = {
        "aws_region": request.headers.get("region_name")
    }
    secrets = {
        "aws": {
            "aws_access_key_id": request.headers.get("aws_access_key_id"),
            "aws_secret_access_key": request.headers.get("aws_secret_access_key"),
        }}
    response.status_code = status.HTTP_200_OK
    return chaosaws.ec2.actions.attach_volume(instance_ids=id.split(','), configuration=configuration, secrets=secrets)


def detach_random_volume(id, request, response):
    configuration = {
        "aws_region": request.headers.get("region_name")
    }
    secrets = {
        "aws": {
            "aws_access_key_id": request.headers.get("aws_access_key_id"),
            "aws_secret_access_key": request.headers.get("aws_secret_access_key"),
        }}
    response.status_code = status.HTTP_200_OK
    return chaosaws.ec2.actions.detach_random_volume(instance_ids=id.split(','), configuration=configuration,
                                                     secrets=secrets)


def terminate_instance(id, request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('ec2', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.terminate_instances(InstanceIds=id.split(','))
    response.status_code = status.HTTP_200_OK
    return res


def stop_instance(id, request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")

    client = boto3.client('ec2', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.stop_instances(InstanceIds=id.split(','))
    response.status_code = status.HTTP_200_OK
    return res


def stop_instances(id, request, response):
    configuration = {
        "aws_region": request.headers.get("region_name")
    }
    secrets = {
        "aws": {
            "aws_access_key_id": request.headers.get("aws_access_key_id"),
            "aws_secret_access_key": request.headers.get("aws_secret_access_key"),
        }}
    response.status_code = status.HTTP_200_OK
    return chaosaws.ec2.actions.stop_instances(instance_ids=id.split(','), configuration=configuration, secrets=secrets)


def start_instances(id, request, response):
    # configuration = {
    #     "aws_region": request.headers.get("aws_region")
    # }
    # secrets = {
    #     "aws": {
    #         "aws_access_key_id": request.headers.get("aws_access_key_id"),
    #         "aws_secret_access_key": request.headers.get("aws_secret_access_key"),
    #     }}
    # response.status_code = status.HTTP_200_OK
    # return chaosaws.ec2.actions.start_instances(instance_ids=id.split(','), configuration=configuration,
    #                                             secrets=secrets)
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('ec2', aws_access_key_id=aws_access_key_id, aws_secrer_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.start_instances(InstanceIds=id.split(","))
    print(id)
    response.status_code = status.HTTP_200_OK
    return res


def restart_instances(id, request, response):
    configuration = {
        "aws_region": request.headers.get("region_name")
    }
    secrets = {
        "aws": {
            "aws_access_key_id": request.headers.get("aws_access_key_id"),
            "aws_secret_access_key": request.headers.get("aws_secret_access_key"),
        }}
    response.status_code = status.HTTP_200_OK
    return chaosaws.ec2.actions.restart_instances(instance_ids=id.split(','), configuration=configuration,
                                                  secrets=secrets)
