import boto3
from starlette import status


def list_services():
    services = ["ec2", "ecs", "rds", "s3", "lambda", "eks", "asg", "dynamoDB"]
    return services


def list_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    resource = boto3.client('resourcegroupstaggingapi', aws_access_key_id=aws_access_key_id,
                            aws_secret_access_key=aws_secret_access_key, region_name=region_name)
    res = resource.get_resources()
    data = []
    for resourceatagmappinglist in res['ResourceTagMappingList']:
        split = resourceatagmappinglist['ResourceARN'].split("/")
        id = split[-1]
        resource_name = split[0].split(":")[-1]
        data.append({
            "id": id,
            "resource_name": resource_name
        })

    response.status_code = status.HTTP_200_OK
    return data


def s3_resource(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    s3Bucket = boto3.resource('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                        region_name=region_name)
    res = s3.list_buckets()
    result = {key: res[key] for key in res if key == "Buckets"}
    response.status_code = status.HTTP_200_OK
    return result


def lambda_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('lambda', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.list_functions()
    function = res["Functions"]
    fn = []
    for func in function:
        f = {"FunctionName": func["FunctionName"],
             "Timeout": func["Timeout"],
             "MemorySize": func["MemorySize"]
             }
        fn.append(f)
    response.status_code = status.HTTP_200_OK
    return fn


def describe_function(request, response, function):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('lambda', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.get_function(FunctionName=function)
    ret = {key: res[key] for key in res if key == "Configuration"}
    event = client.list_event_source_mappings(FunctionName=function)
    event_id = {key:event[key] for key in event if key == "EventSourceMappings"}
    id = event_id["EventSourceMappings"][0]["UUID"]
    print(id)
    uuid = {"UUID": id}
    response.status_code = status.HTTP_200_OK
    return ret, event_id