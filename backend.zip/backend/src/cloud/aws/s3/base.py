import boto3
from starlette import status


def describe_bucket(request, response, bucket):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    s3 = boto3.resource('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                        region_name=region_name)
    s3Bucket = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                            region_name=region_name)
    res = s3.Bucket(bucket)
    ds = []
    for objects in res.objects.all():
        d = {"Object": objects.key
             }
        ds.append(d)
    res1 = s3Bucket.get_bucket_versioning(Bucket=bucket)
    ret = {key: res1[key] for key in res1 if key == "Status"}
    response.status_code = status.HTTP_200_OK
    return ds, ret


def list_bucket_versioning(response, request, bucket):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                      region_name=region_name)
    res1 = s3.get_bucket_versioning(Bucket=bucket)
    ret = {key: res1[key] for key in res1 if key == "Status"}
    response.status_code = status.HTTP_200_OK
    return ret
