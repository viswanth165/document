import boto3

from starlette import status


def list_db_cluster(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    rds = boto3.client('rds', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = rds.describe_db_clusters()

    dBClusters = res["DBClusters"]
    d = []
    for db in dBClusters:
        f = {"DBClusterIdentifier": db["DBClusterIdentifier"],
             "Endpoint": db["Endpoint"],
             "DBClusterMembers": db["DBClusterMembers"]}
        d.append(f)
    response.status_code = status.HTTP_200_OK
    return d


def describe_db_cluster(request, response, dbclusteridentifier):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    rds = boto3.client('rds', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = rds.describe_db_clusters(DBClusterIdentifier=dbclusteridentifier)
    ret = {key: res[key] for key in res if key == "DBClusters"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_db_instances(request, response, dbinstanceidentifier):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    rds = boto3.client('rds', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = rds.describe_db_instances(DBInstanceIdentifier=dbinstanceidentifier)
    ret = {key: res[key] for key in res if key == "DBInstances"}
    response.status_code = status.HTTP_200_OK
    return ret
