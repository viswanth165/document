import boto3
from starlette import status


def lambda_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('lambda', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.list_functions()
    print(res)
    response.status_code = status.HTTP_200_OK
    return res


