import boto3
from starlette import status


def ecs_resources(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    client = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                          region_name=region_name)
    res = client.list_clusters()
    ret = {key: res[key] for key in res if key == "clusterArns"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_cluster(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    clus = [cluster]
    res = ecs.describe_clusters(clusters=clus)
    # ret = res["clusters"]
    ret = {key: res[key] for key in res if key == "clusters"}
    response.status_code = status.HTTP_200_OK
    return ret


def list_services(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ecs.list_services(cluster=cluster)
    ret = {key: res[key] for key in res if key == "serviceArns"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_service(request, response, cluster, services):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    svc = [services]
    res = ecs.describe_services(cluster=cluster, services=svc)
    ret = {key: res[key] for key in res if key == "services"}
    response.status_code = status.HTTP_200_OK
    return ret


def list_cluster_tasks(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ecs.list_tasks(cluster=cluster)
    ret = {key: res[key] for key in res if key == "taskArns"}
    response.status_code = status.HTTP_200_OK
    return ret


def list_service_tasks(request, response, cluster, service):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ecs.list_tasks(cluster=cluster, serviceName=service)
    ret = {key: res[key] for key in res if key == "taskArns"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_tasks(request, response, cluster, task):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    t = [task]
    res = ecs.describe_tasks(cluster=cluster, tasks=t)
    ret = {key: res[key] for key in res if key == "tasks"}
    response.status_code = status.HTTP_200_OK
    return ret


def list_container_instances(request, response, cluster):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ecs.list_container_instances(cluster=cluster)
    ret = {key: res[key] for key in res if key == "containerInstanceArns"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_container_instances(request, response, cluster, containerInstance):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    ecs = boto3.client('ecs', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    ci = [containerInstance]
    res = ecs.describe_container_instances(cluster=cluster, containerInstances=ci)
    response.status_code = status.HTTP_200_OK
    return res
