import boto3
from starlette import status


def list_asg(request, response):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    asg = boto3.client('autoscaling', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    auto_sacling_group = []
    res = asg.describe_auto_scaling_groups()
    asg_name = res["AutoScalingGroups"]
    for autoscaling in asg_name:
        f = {"AutoScalingGroupName": autoscaling["AutoScalingGroupName"],
             "VPCZoneIdentifier": autoscaling["VPCZoneIdentifier"]}
        auto_sacling_group.append(f)
    response.status_code = status.HTTP_200_OK
    return auto_sacling_group


def describe_auto_scaling_groups(request, response, asgname):
    aws_access_key_id = request.headers.get("aws_access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_access_key")
    region_name = request.headers.get("region_name")
    asg = boto3.client('autoscaling', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    autoscaling = [asgname]
    res = asg.describe_auto_scaling_groups(AutoScalingGroupNames=autoscaling)
    ret = {key:res[key] for key in res if key == "AutoScalingGroups"}
    response.status_code = status.HTTP_200_OK
    return ret
