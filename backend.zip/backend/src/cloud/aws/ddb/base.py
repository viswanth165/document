import boto3
from starlette import status


def list_table(request, response):
    aws_access_key_id = request.headers.get("aws_Access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_Access_key")
    region_name = request.headers.get("region_name")
    ddb = boto3.client("dynamodb", aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ddb.list_tables()
    ret = {key: res[key] for key in res if key == "TableNames"}
    response.status_code = status.HTTP_200_OK
    return ret


def describe_table(request, response, table):
    aws_access_key_id = request.headers.get("aws_Access_key_id")
    aws_secret_access_key = request.headers.get("aws_secret_Access_key")
    region_name = request.headers.get("region_name")
    ddb = boto3.client("dynamodb", aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key,
                       region_name=region_name)
    res = ddb.describe_table(TableName=table)
    ret = {key:res[key] for key in res if key == "Table"}
    response.status_code = status.HTTP_200_OK
    return ret

